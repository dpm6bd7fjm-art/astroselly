# AstroSelly — Production v1

A mobile-first AI astrology website with an Egyptian-inspired earth-tone visual identity.

## Included
- Responsive frontend
- Chart image upload (PNG/JPG/WEBP)
- Birth date/time/place inputs
- Secure serverless `/api/analyze` endpoint
- OpenAI Responses API image analysis
- Structured AstroSelly interpretation prompt
- No login
- Basic error handling and image compression

## Deployment
This project is designed for Vercel because GitHub Pages cannot safely keep an OpenAI API key server-side.

1. Import this repository into Vercel.
2. Add an environment variable named `OPENAI_API_KEY`.
3. Deploy.
4. Open the Vercel URL and test with a chart image.

Never put the API key inside `index.html` or any public file.

The OpenAI API supports image inputs in the Responses API; the backend uses an `input_image` data URL so the key remains server-side.
