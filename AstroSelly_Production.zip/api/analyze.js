import OpenAI from "openai";

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const { imageData, date, time, place } = req.body || {};
    if (!imageData && !date) return res.status(400).json({ error: "Provide a chart image or birth data." });

    const instructions = `You are AstroSelly AI, an astrology interpretation assistant.
Your job is to analyze the user's provided natal chart image and/or birth details in a structured, nuanced way.
IMPORTANT:
- Treat astrology as a symbolic/spiritual interpretive framework, not as scientifically proven fact.
- Never invent a placement. If a chart image is unclear, explicitly say what cannot be read.
- Do not diagnose medical or mental-health conditions and do not make deterministic claims about death, disease, disasters, or guaranteed future events.
- If exact birth details are provided, use them as context but do not pretend you performed astronomical calculations unless the data is actually available.
- Write a warm, sophisticated report with clear headings.
- Prioritize: Big 3, dominant element/modality, chart ruler, planetary emphasis, houses, major aspects, dispositorship, evolutionary themes, and (when enough information exists) a Vedic layer.
- End with practical reflective prompts, not commands or predictions.
Return plain text only.`;

    const userText = `Create an AstroSelly natal-chart reading.
Birth date: ${date || "not provided"}
Birth time: ${time || "not provided"}
Birth place: ${place || "not provided"}

Analyze the uploaded chart image if present. Start by stating which chart details you can actually read.`;

    const content = [{ type: "input_text", text: userText }];
    if (imageData) {
      content.push({ type: "input_image", image_url: imageData, detail: "high" });
    }

    const response = await client.responses.create({
      model: "gpt-5",
      instructions,
      input: [{ role: "user", content }]
    });

    return res.status(200).json({ analysis: response.output_text });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: "AstroSelly could not complete the analysis. Check the API configuration and try again." });
  }
}
